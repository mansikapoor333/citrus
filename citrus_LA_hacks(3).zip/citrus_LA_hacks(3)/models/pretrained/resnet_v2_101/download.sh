#! /bin/bash

wget http://download.tensorflow.org/models/resnet_v2_101_2017_04_14.tar.gz
tar -xvf resnet_v2_101_2017_04_14.tar.gz
rm resnet_v2_101_2017_04_14.tar.gz
